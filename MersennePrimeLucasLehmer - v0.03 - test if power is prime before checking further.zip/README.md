# Math - Prime Numbers - Largest, Lucas-Lehmer

My Java code to determine if a number of the form 2^N - 1 is a Mersenne Prime,
using Lucas-Lehmer Numbers.


## Useful Links:


* **How they found the World's Biggest Prime Number - Numberphile**,
Stand-up Maths / Matt Parker, Jan 21, 2016
https://www.youtube.com/watch?v=lEvXcTYqtKU


**Moose**
<br>Moose's Software Valley - Established July, 1996.
<br>https://moosevalley.github.io/
